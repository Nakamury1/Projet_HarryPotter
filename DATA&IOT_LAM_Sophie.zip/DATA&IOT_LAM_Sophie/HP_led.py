from machine import Pin, PWM # importe dans le code la lib qui permet de gerer les Pin de sortie et de modulation du signal
from random import randint
import network   #import des fonction lier au wifi
import urequests	#import des fonction lier au requetes http
import utime	#import des fonction lier au temps
import ujson	#import des fonction lier à la convertion en Json
import random

pwm_ledBleu = PWM(Pin(16,mode=Pin.OUT)) 	# on precise au programme que la pin 16 est une sortie de type PWN
pwm_ledVert = PWM(Pin(17,mode=Pin.OUT))
pwm_ledRouge = PWM(Pin(18,mode=Pin.OUT))
pwm_ledRouge.duty_u16(10000)				# on lui donne une valeur comprise entre 0 et 65535 qui est converti entre 0 et 3.3v
pwm_ledVert.duty_u16(10000)
pwm_ledBleu.duty_u16(10000)

# déclaration des variables
couleurDépart = [10000, 10000, 10000]
maisons = {"Gryffindor": [10000,0,0], "Ravenclaw": [0,0,10000], "Hufflepuff": [10000,10000,0], "Slytherin": [0,10000,0]}

wlan = network.WLAN(network.STA_IF) # met la raspi en mode client wifi
wlan.active(True) # active le mode client wifi

ssid = 'Redmi Note 8T'
password = 'labierecorona'
wlan.connect(ssid, password) # connecte la raspi au réseau
url = "https://hp-api.lainocs.fr/characters/"

while not wlan.isconnected():
    print("pas co")
    utime.sleep(1)
    pass

while(True):
    try:
        print("GET")
        r = urequests.get(url) # lance une requete sur l'url
        print(r.json()) # traite sa reponse en Json
        aleatoire = randint(0,len(r.json())-1)		# Variable qui affiche aléatoirement une valeur comprise entre 0 et le nombre de sorciers contenu dans l'API
        slug = r.json()[aleatoire]["slug"]			# variable qui affiche le nom du personnage
        print(slug)
        house = r.json()[aleatoire]["house"]		# variable qui affiche la maison du personnage ou n'affiche rien le personnage n'a pas de maison
        print(house)
        pwm_ledRouge.duty_u16(maisons[house][0]) 	# allume la led en Rouge si le personnage vient de Gryffindor
        pwm_ledVert.duty_u16(maisons[house][1])		# allume la led en Vert si le personnage vient de Slytherin
        pwm_ledBleu.duty_u16(maisons[house][2])		# allume la led en Bleu si le personnage vient de Ravenclaw
                                                    # allume la led en Jaune si le personnage vient de Poufsouffle
        r.close() # ferme la demande
        utime.sleep(1)
    except Exception as e:
        print(e)

